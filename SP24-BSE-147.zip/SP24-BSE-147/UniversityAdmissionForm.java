package org.example.demo;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

import java.io.File;
import java.util.ArrayList;

public class UniversityAdmissionForm extends Application {

    // ArrayList to store form data
    private final ArrayList<String> formData = new ArrayList<>();
    private Scene formScene; // Store a reference of form scene

    public void start(Stage stage) {
        // Root Pane
        VBox root = new VBox();
        root.setAlignment(Pos.CENTER);
        root.setStyle("-fx-background-color: #F4F4F9;");
        root.setSpacing(0);

        // Banner
        HBox banner = new HBox();
        banner.setAlignment(Pos.CENTER);
        banner.setPadding(new Insets(15));
        banner.setMaxWidth(500); // Match the width of the form
        banner.setStyle("-fx-background-color: #03396C; -fx-border-color: #03396C; " +
                "-fx-border-width: 2px; -fx-border-radius: 5px 5px 0px 0px; " +
                "-fx-background-radius: 5px 5px 0px 0px;");

        Label bannerTitle = new Label("University Admission Form");
        bannerTitle.setFont(Font.font("Arial", 24));
        bannerTitle.setTextFill(Color.WHITE);
        banner.getChildren().add(bannerTitle);

        // Form Layout
        GridPane gridPane = new GridPane();
        gridPane.setAlignment(Pos.CENTER);
        gridPane.setHgap(10);
        gridPane.setVgap(15);
        gridPane.setPadding(new Insets(50, 30, 50, 30));
        gridPane.setMaxWidth(500); // Fixed width for form
        gridPane.setStyle("-fx-background-color: #FFFFFF; -fx-border-color: #03396C; " +
                "-fx-border-width: 0px 2px 2px 2px; -fx-border-radius: 0px 0px 5px 5px; " +
                "-fx-background-radius: 0px 0px 5px 5px;");

        Label nameLabel = new Label("Name : ");
        TextField nameField = new TextField();
        nameLabel.setStyle("-fx-font-weight: bold");
        nameLabel.setFont(Font.font("Poppins", 15));
        gridPane.add(nameLabel, 0, 0);
        gridPane.add(nameField, 1, 0);

        Label fatherNameLabel = new Label("Father Name :");
        TextField fatherNameField = new TextField();
        fatherNameLabel.setStyle("-fx-font-weight: bold");
        fatherNameField.setFont(Font.font("Poppins", 15));
        styleField(fatherNameField);
        gridPane.add(fatherNameLabel, 0, 1);
        gridPane.add(fatherNameField, 1, 1);

        Label emailLabel = new Label("Email :");
        TextField emailField = new TextField();
        emailLabel.setFont(Font.font("Poppins", 15));
        emailLabel.setStyle("-fx-font-weight: bold");
        styleField(emailField);
        gridPane.add(emailLabel, 0, 2);
        gridPane.add(emailField, 1, 2);

        Label addressLabel = new Label("Address :");
        TextField addressField = new TextField();
        addressLabel.setFont(Font.font("Poppins", 15));
        addressLabel.setStyle("-fx-font-weight: bold");
        styleField(addressField);
        gridPane.add(addressLabel, 0, 3);
        gridPane.add(addressField, 1, 3);

        Label cityLabel = new Label("City :");
        TextField cityField = new TextField();
        cityLabel.setFont(Font.font("Poppins", 15));
        cityLabel.setStyle("-fx-font-weight: bold");
        styleField(cityField);
        gridPane.add(cityLabel, 0, 4);
        gridPane.add(cityField, 1, 4);

        Label genderLabel = new Label("Gender:");
        genderLabel.setStyle("-fx-font-weight: bold");
        genderLabel.setFont(Font.font("Poppins", 15));
        HBox genderBox = new HBox(10);
        ToggleGroup genderGroup = new ToggleGroup();
        RadioButton maleRadio = new RadioButton("Male");
        RadioButton femaleRadio = new RadioButton("Female ");
        maleRadio.setToggleGroup(genderGroup);
        femaleRadio.setToggleGroup(genderGroup);
        genderBox.getChildren().addAll(maleRadio, femaleRadio);
        genderBox.setAlignment(Pos.CENTER_LEFT);
        gridPane.add(genderLabel, 0, 5);
        gridPane.add(genderBox, 1, 5);

        Label programLabel = new Label("Program:");
        programLabel.setFont(Font.font("Poppins", 15));
        programLabel.setStyle("-fx-font-weight: bold");
        ComboBox<String> programComboBox = new ComboBox<>();
        programComboBox.getItems().addAll("Computer Science", "Software Engineering", "Artificial Intelligence",
                "Data Sciences", "Cyber Security", "Computer Engineering");
        programComboBox.setPromptText("Select a Program");
        styleField(programComboBox);
        gridPane.add(programLabel, 0, 6);
        gridPane.add(programComboBox, 1, 6);

        Label imageChooseLabel = new Label("Upload Image:");
        Button imageChooseButton = new Button("Choose Image");
        imageChooseLabel.setFont(Font.font("Poppins", 15));
        imageChooseLabel.setStyle("-fx-font-weight: bold");
        ImageView imageView = new ImageView();
        imageView.setFitWidth(80);
        imageView.setFitHeight(80);
        imageView.setPreserveRatio(true);
        imageView.setStyle("-fx-border-color: #DDD; -fx-border-width: 1px;");

        FileChooser fileChooser = new FileChooser();
        fileChooser.getExtensionFilters().add(
                new FileChooser.ExtensionFilter("Image Files", "*.png", "*.jpg", "*.jpeg", "*.gif")
        );

        imageChooseButton.setOnAction(e -> {
            File selectedFile = fileChooser.showOpenDialog(stage);
            if (selectedFile != null) {
                try {
                    Image image = new Image(selectedFile.toURI().toString());
                    imageView.setImage(image);
                } catch (Exception ex) {
                    showAlert("Error", "Failed to load the image.");
                }
            }
        });

        gridPane.add(imageChooseLabel, 0, 7);
        gridPane.add(imageChooseButton, 1, 7);
        gridPane.add(imageView, 1, 8); // Display image below button

        Button submitButton = new Button("Submit");
        submitButton.setStyle("-fx-background-color: #03396C; -fx-text-fill: white; " +
                "-fx-font-size: 16px; -fx-padding: 10 30; -fx-border-radius: 5px; -fx-background-radius: 5px; -fx-cursor: pointer");
        gridPane.add(submitButton, 0, 9, 2, 1); // Span 2 columns
        GridPane.setMargin(submitButton, new Insets(20, 0, 0, 0));

        submitButton.setOnAction(event -> {
            String name = nameField.getText();
            String fatherName = fatherNameField.getText();
            String email = emailField.getText();
            String address = addressField.getText();
            String city = cityField.getText();
            String gender = ((RadioButton) genderGroup.getSelectedToggle()).getText();
            String program = programComboBox.getValue();

            // Add form data to ArrayList
            formData.add("Name: " + name);
            formData.add("Father's Name: " + fatherName);
            formData.add("Email: " + email);
            formData.add("Address: " + address);
            formData.add("City: " + city);
            formData.add("Gender: " + gender);
            formData.add("Program: " + program);

            showDataScene(stage);
        });

        root.getChildren().addAll(banner, gridPane);

        // Create the form scene and store it in the formScene variable
        formScene = new Scene(root, 700, 700);
        stage.setTitle("University Admission Form");
        stage.setScene(formScene);
        stage.show();
    }

    private void styleField(Region input) {
        input.setStyle("-fx-font-size: 14px; -fx-border-color: #ccc; -fx-border-width: 1px; " +
                "-fx-border-radius: 5px; -fx-padding: 5;");
        input.setMaxWidth(280);
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    private void showDataScene(Stage stage) {
        VBox dataRoot = new VBox();
        dataRoot.setSpacing (15);
        dataRoot.setPadding(new Insets(20));
        dataRoot.setStyle("-fx-background-color: #F4F4F9;");

        Label dataTitle = new Label("Form Data");
        dataTitle.setFont(Font.font("Poppins", 24));
        dataRoot.getChildren().add(dataTitle);

        for (String data : formData) {
            Label dataLabel = new Label(data);
            dataLabel.setFont(Font.font("Poppins", 16));
            dataRoot.getChildren().add(dataLabel);
        }

        Button backButton = new Button("Back to Form");
        backButton.setStyle("-fx-background-color: #03396C; -fx-text-fill: white; -fx-padding: 10;");
        backButton.setOnAction(e -> stage.setScene(formScene));

        dataRoot.getChildren().add(backButton);
        Scene dataScene = new Scene(dataRoot, 600, 600);
        stage.setScene(dataScene);
    }

    public static void main(String[] args) {
        launch(args);
    }
}